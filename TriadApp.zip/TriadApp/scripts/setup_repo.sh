#!/usr/bin/env bash
set -e
REPO_DIR=~/repo/TriadApp

# Create the main directory if it does not exist
mkdir -p "$REPO_DIR"/{100_Skills_Genealogy,200_Failure_Signatures,300_Gap_Specifications,400_Skill_Templates,scripts}

# Create README.md if it does not exist
if [ ! -f "$REPO_DIR/README.md" ]; then
  cat > "$REPO_DIR/README.md" <<'EOF'
# Error-to-Skill Transformation – Deterministic Pipeline

This repository contains the full specification of the Error-to-Skill pipeline,
including architecture, step‑by‑step pipeline description, pseudocode,
verification checklist, and a setup script.

## TL;DR

- Failure -> FailureSignature -> Backward-Goal Derivation -> Gap Specification -> Skill Template -> Skill Instantiation -> Validation -> Persistence.
- Every step writes an immutable artifact to the vault.
- The process is fully auditable and reproducible.
EOF
fi

# Create ARCHITECTURE.md if it does not exist
if [ ! -f "$REPO_DIR/ARCHITECTURE.md" ]; then
  cat > "$REPO_DIR/ARCHITECTURE.md" <<'EOF'
# Architecture Overview

The system is built around the Unified Cognitive Architecture (UCA).

Key components:
- Recursor-Agent – orchestrates the full lifecycle: ingest task -> execute -> detect failure -> extract FailureSignature -> Backward-Goal Derivation -> Gap Specification -> Skill Template -> Skill Instantiation -> Validation -> Persist.
- FailureSignature Generation – proof-by-failure extracts a signature that records the exact missing component, its depth, and confidence.
- Backward-Goal Derivation – backward-goal-derivation computes the minimal set of primitives (the gap specification) required to satisfy the target goal.
- Skill-Template Generation – skill-gap-discovery converts that gap into a concrete SKILL.md template (title, description, step list, test harness).
- Skill Instantiation – skill-acquisition-and-generation fills the template inside a sandboxed Python REPL, writes the actual code, and runs the supplied unit tests.
- Validation – executes the new skill on the original failing task; if it succeeds the skill is committed, otherwise the template is patched and the loop restarts.
- Persistence & Auditing – artefacts are stored under 200_Failure_Signatures/, 300_Gap_Specifications/, 400_Skill_Templates/, and 100_Skills_Genealogy/ respectively. A cryptographic hash guarantees immutability and full provenance.
- Audit & Loop Control – the system updates its Generative Freshness Indicator (GFI), runs the audit layers (MAIR, NGS, PCN), and may rotate blind-spots or inject perturbations before feeding the next task into the loop.

All artefacts are plain-text markdown, yaml, and python scripts under version control. The pipeline is fully deterministic, auditable, and can be reproduced on any clone of the repository.
EOF
fi

# Create PIPELINE.md if it does not exist
if [ ! -f "$REPO_DIR/PIPELINE.md" ]; then
  cat > "$REPO_DIR/PIPELINE.md" <<'EOF'
# Pipeline

1. **FailureSignature Generation** – proof-by-failure extracts a signature that records the exact missing component, its depth, and confidence.

2. **Backward-Goal Derivation** – backward-goal-derivation computes the minimal set of primitives (the gap specification) required to satisfy the target goal.

3. **Skill-Template Generation** – skill-gap-discovery converts that gap into a concrete SKILL.md template (title, description, step list, test harness).

4. **Skill Instantiation** – skill-acquisition-and-generation fills the template inside a sandboxed Python REPL, writes the actual code, and runs the supplied unit tests.

5. **Validation** – executes the new skill on the original failing task; if it succeeds the skill is committed, otherwise the template is patched and the loop restarts.

6. **Persistence & Auditing** – artefacts are stored under 200_Failure_Signatures/, 300_Gap_Specifications/, 400_Skill_Templates/, and 100_Skills_Genealogy/ respectively. A cryptographic hash guarantees immutability and full provenance.

7. **Audit & Loop Control** – the system updates its Generative Freshness Indicator (GFI), runs the audit layers (MAIR, NGS, PCN), and may rotate blind-spots or inject perturbations before feeding the next task into the loop.

## Pseudocode (Python)

def closed_loop(task_id, task_desc):
    exec_res = hermes_execute(task_id, task_desc)
    if not exec_res.success:
        signature = proof_by_failure(exec_res.trace)
        gap_spec  = backward_goal_derivation(signature)
        template  = skill_gap_discovery(gap_spec)
        skill_dir = skill_acquisition_and_generation(template)
        if hermes_execute(task_id, task_desc, skill_dir).success:
            record_skill_generation(signature, gap_spec, template, skill_dir)
            update_audits()
        else:
            mutated = skill_mutation_scaffolding(template, retry_trace)
            return closed_loop(task_id, task_desc)   # retry with patched template
    return {"status":"completed","skill_added":True}
EOF
fi

# Create VALIDATION_CHECKLIST.md if it does not exist
if [ ! -f "$REPO_DIR/VALIDATION_CHECKLIST.md" ]; then
  cat > "$REPO_DIR/VALIDATION_CHECKLIST.md" <<'EOF'
# Validation Checklist

Step 1 – FailureSignature
Verification: ls 200_Failure_Signatures/.json | wc -l

Step 2 – GapSpecification
Verification: cat 300_Gap_Specifications/<sig>.yaml | head -n 20

Step 3 – SkillTemplate
Verification: grep "^# Title" 400_Skill_Templates/*.md

Step 4 – Instantiated Skill
Verification: md5sum 100_Skills_Genealogy/<skill>/skill.md

Step 5 – Validation Result
Verification: grep "PASS" 100_Skills_Genealogy/<skill>/test_output.log

Step 6 – Persistence
Verification: git log --oneline --follow 100_Skills_Genealogy/ | head -n 5

Step 7 – Audit Update
Verification: cat 000_System_State/current_gfi.md
EOF
fi

# Create .gitignore if it does not exist
if [ ! -f "$REPO_DIR/.gitignore" ]; then
  cat > "$REPO_DIR/.gitignore" <<'EOF'
# Ignore runtime artefacts
__pycache__/
*.pyc
*.pyo
*.egg-info/
*.egg
*.log
*.tmp
EOF
fi

echo "Repository scaffold created at $REPO_DIR"