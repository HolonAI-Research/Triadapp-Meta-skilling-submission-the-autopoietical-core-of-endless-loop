#!/usr/bin/env bash
# Resilience health check script for TrueFoundry providers
# Outputs JSON with status for each provider (ok/failure/error)

PROVIDERS='openai claude local_llm'
for p in $PROVIDERS; do
  echo -n "$p: "
  # Try a simple ping via Hermes; on any error output 'error'
  STATUS=$(hermes_execute ping-$p --json 2>/dev/null || echo "error")
  echo "$STATUS"
done