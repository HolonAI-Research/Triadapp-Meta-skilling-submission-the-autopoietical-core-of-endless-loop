# Lark Integration Blueprint

## Quickstart Overview
- Lark CLI: https://docs.getlark.ai/cli
- Lark MCP quickstart: https://docs.getlark.ai/mcp-quickstart
- Documentation portal: https://docs.getlark.ai/quickstart

## Core Use‑Cases
1. **Issue‑Verification Bot**
   - Slack/Discord command triggers a Lark workflow.
   - Workflow validates the reported issue, reproduces steps, returns a pass/fail badge.
2. **Linear Extension**
   - Hook into Linear tickets; on ticket creation, launch a Lark MCP job to spin up a reproducible environment.
3. **Coding Agent**
   - Listen for failing tests in CI; when a test fails, the agent drafts a PR with a fix.
4. **GitHub Extension**
   - On each commit, the agent suggests new Lark test cases using the Lark CLI.
5. **TUI Manager**
   - Interactive text UI to list, start, stop Lark workflows; supports async dispatch.

## Sample Workflow: Linear Issue → Lark Test Reproduction
1. User posts issue link in Slack → bot triggers `lark start reproduce_issue --ticket $LINEAR_ID`.
2. Lark MCP parses the ticket, pulls test repo, runs the test suite.
3. Results stored under `reports/<ticket_hash>/` with a summary file.
4. Bot posts back a formatted result in Slack with `✅ PASS` or `❌ FAIL` and a link to the report.

## Configuration Files
### Lark CLI profile (saved in `~/.lark/config.yaml`)
```yaml
api_token: YOUR_LARK_TOKEN
default_project: DEV
default_endpoint: https://api.larkapp.com
```

### MCP Server registration (saved in `~/.hermes/mcp_servers.json`)
```json
{
  "lark-mcp": {
    "command": "lark",
    "args": ["mcp", "run", "--profile", "default"]
  }
}
```

## Automation Scripts
### `scripts/run_lark_workflow.sh`
```bash
#!/usr/bin/env bash
# Arguments: <workflow_name> [args...]
WORKFLOW=$1
shift
lark run "$WORKFLOW" -- "$@"
```

### `scripts/test_lark_integration.py`
```python
import subprocess, json, pathlib, sys

def run_lark_workflow(name, args):
    result = subprocess.run(
        ["bash", "scripts/run_lark_workflow.sh", name] + args,
        capture_output=True,
        text=True,
    )
    print(f"[{name}] exit_code={result.returncode}")
    print(result.stdout)
    if result.stderr:
        print("STDERR:", result.stderr)
    return result.returncode == 0

if __name__ == "__main__":
    # Example: run the reproduction workflow for ticket ABC-123
    success = run_lark_workflow("reproduce_issue", ["--ticket", "ABC-123"])
    sys.exit(0 if success else 1)
```

## Verification Checklist (add to VALIDATION_CHECKLIST.md)
- [ ] Lark CLI is installed and version printed (`lark --version`).
- [ ] MCP server entry points load without errors (`hermes mcp list`).
- [ ] Sample workflow runs successfully (`scripts/run_lark_workflow.sh list`).
- [ ] Report directory `reports/` contains at least one summary file after execution.
- [ ] CI pipeline includes a step `make test-lark` that invokes `scripts/test_lark_integration.py`.

## Resilience Considerations
- **MCP Server Failure:** If the Lark MCP process crashes, the Hermes Agent detects the failure via the `process` tool, retries, and if persistent, rotates the blind‑spot assignments using `pcn-blindspot-registry`.
- **LLM Backend Errors:** Use the same fallback pattern described in `docs/truefoundry_resilience.md` – the agent can switch to a secondary MCP provider (e.g., a dummy echo server) and continue operation.

## Extending the Blueprint
- Add more workflow definitions under `workflows/` as individual markdown files.
- Hook each workflow to a GitHub webhook or Linear trigger via `curl` calls inside the workflow scripts.
- Store all workflow definitions under `skills/lark-workflows/` for versioned reuse.

--- 

*All scripts and configuration snippets are ASCII‑only and ready to be committed directly to the repository.* 