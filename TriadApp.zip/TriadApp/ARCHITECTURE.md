# Architecture Overview

The system is built around the Unified Cognitive Architecture (UCA).

Key components:
- Recursor-Agent – orchestrates the full lifecycle: ingest task -> execute -> detect failure -> extract FailureSignature -> Backward-Goal Derivation -> Gap Specification -> Skill Template -> Skill Instantiation -> Validation -> Persist
- FailureSignature Generation – proof-by-failure extracts a signature that records the exact missing component, its depth, and confidence
- Backward-Goal Derivation – backward-goal-derivation computes the minimal set of primitives (the gap specification) required to satisfy the target goal
- Skill-Template Generation – skill-gap-discovery converts that gap into a concrete SKILL.md template (title, description, step list, test harness)
- Skill Instantiation – skill-acquisition-and-generation fills the template inside a sandboxed Python REPL, writes the actual code, and runs the supplied unit tests
- Validation – executes the new skill on the original failing task; if it succeeds the skill is committed, otherwise the template is patched and the loop restarts
- Persistence & Auditing – artefacts are stored under 200_Failure_Signatures/, 300_Gap_Specifications/, 400_Skill_Templates/, and 100_Skills_Genealogy/ respectively. A cryptographic hash guarantees immutability and full provenance
- Audit & Loop Control – the system updates its Generative Freshness Indicator (GFI), runs the audit layers (MAIR, NGS, PCN), and may rotate blind-spots or inject perturbations before feeding the next task into the loop

All artefacts are plain-text markdown, yaml, and python scripts under version control. The pipeline is fully deterministic, auditable, and can be reproduced on any clone of the repository