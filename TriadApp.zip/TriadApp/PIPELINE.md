# Pipeline

1. **FailureSignature Generation** – proof-by-failure extracts a signature that records the exact missing component, its depth, and confidence.

2. **Backward-Goal Derivation** – backward-goal-derivation computes the minimal set of primitives (the gap specification) required to satisfy the target goal.

3. **Skill-Template Generation** – skill-gap-discovery converts that gap into a concrete SKILL.md template (title, description, step list, test harness).

4. **Skill Instantiation** – skill-acquisition-and-generation fills the template inside a sandboxed Python REPL, writes the actual code, and runs the supplied unit tests.

5. **Validation** – executes the new skill on the original failing task; if it succeeds the skill is committed, otherwise the template is patched and the loop restarts.

6. **Persistence & Auditing** – artefacts are stored under 200_Failure_Signatures/, 300_Gap_Specifications/, 400_Skill_Templates/, and 100_Skills_Genealogy/ respectively. A cryptographic hash guarantees immutability and full provenance.

7. **Audit & Loop Control** – the system updates its Generative Freshness Indicator (GFI), runs the audit layers (MAIR, NGS, PCN), and may rotate blind-spots or inject perturbations before feeding the next task into the loop.

## Pseudocode (Python)

def closed_loop(task_id, task_desc):
    exec_res = hermes_execute(task_id, task_desc)
    if not exec_res.success:
        signature = proof_by_failure(exec_res.trace)
        gap_spec  = backward_goal_derivation(signature)
        template  = skill_gap_discovery(gap_spec)
        skill_dir = skill_acquisition_and_generation(template)
        if hermes_execute(task_id, task_desc, skill_dir).success:
            record_skill_generation(signature, gap_spec, template, skill_dir)
            update_audits()
        else:
            mutated = skill_mutation_scaffolding(template, retry_trace)
            return closed_loop(task_id, task_desc)   # retry with patched template
    return {"status":"completed","skill_added":True}